# plugin.audio.spotify
Unofficial spotify plugin for Kodi, (for now) not yet available in the official Kodi repo.

Based on the opensource Librespot client. Special thanks to mherger for building the special spotty binaries, based on librespot.


## Install with repository
Install the add-on from my Kodi repo:
https://github.com/marcelveldt/repository.marcelveldt/raw/master/repository.marcelveldt/repository.marcelveldt-1.0.1.zip


## Support
Support is provided on the Kodi forums:
http://forum.kodi.tv/showthread.php?tid=265356
Or create issue in Github


## Help needed with maintaining !
I am very busy currently so I do not have a lot of time to work on this project or watch the forums.
Be aware that this is a community driven project, so feel free to submit PR's yourself to improve the code and/or help others with support on the forums etc. If you're willing to really participate in the development, please contact me so I can give you write access to the repo. I do my best to maintain the project every once in a while, when I have some spare time left.
Thanks for understanding!
