# Kodi module port of pyDes

This is module port of Todd Whiteman's [pyDes](https://github.com/twhiteman/pyDes), a pure python implementation of the DES encryption algorithm.
