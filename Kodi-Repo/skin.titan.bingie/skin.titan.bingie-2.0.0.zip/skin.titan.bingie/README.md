# Skin Titan BINGIE

The new Titan for Kodi Leia...
Titan BINGIE is a Titan fork that supports Kodi Leia and adds the new BINGIE layout which simulates Netflix UI for TV remote users.

# Terms of use
With the installation of the skin you agree that you don't use it in combination with blacklisted and illegal Kodi add-ons. I'm not associated with any available build and I won't give any support to blacklisted, banned or illegal third party addons.

# License
This work has been released under GNU General Public License v2.0.

# IMPORTANT NOTE FOR USERS
Install the skin through the official bingie repository for updates and the supported addons required!
The content here is for developing purposes!
https://github.com/cartmandos/repository.bingie

Join the official thread for updates: https://forum.kodi.tv/showthread.php?tid=334820
